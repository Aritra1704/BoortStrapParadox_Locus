package com.boostramp.skillzenza.locations;

import org.springframework.data.repository.CrudRepository;

public interface TempOSRMLocationRepository extends CrudRepository<Location, Integer> {

}
