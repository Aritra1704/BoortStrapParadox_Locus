
package com.boostramp.skillzenza.modal.locasmodals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "out",
    "entry",
    "bearings",
    "location",
    "in"
})
public class Intersection {

    @JsonProperty("out")
    private Integer out;
    @JsonProperty("entry")
    private List<Boolean> entry = null;
    @JsonProperty("bearings")
    private List<Integer> bearings = null;
    @JsonProperty("location")
    private List<Double> location = null;
    @JsonProperty("in")
    private Integer in;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("out")
    public Integer getOut() {
        return out;
    }

    @JsonProperty("out")
    public void setOut(Integer out) {
        this.out = out;
    }

    @JsonProperty("entry")
    public List<Boolean> getEntry() {
        return entry;
    }

    @JsonProperty("entry")
    public void setEntry(List<Boolean> entry) {
        this.entry = entry;
    }

    @JsonProperty("bearings")
    public List<Integer> getBearings() {
        return bearings;
    }

    @JsonProperty("bearings")
    public void setBearings(List<Integer> bearings) {
        this.bearings = bearings;
    }

    @JsonProperty("location")
    public List<Double> getLocation() {
        return location;
    }

    @JsonProperty("location")
    public void setLocation(List<Double> location) {
        this.location = location;
    }

    @JsonProperty("in")
    public Integer getIn() {
        return in;
    }

    @JsonProperty("in")
    public void setIn(Integer in) {
        this.in = in;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
