package com.boostramp.skillzenza.locations;

import java.util.ArrayList;
import java.util.List;

public class MyRoute {

	private List<Location> listLocations = new ArrayList<Location>();
	

	public MyRoute() {
		super();
	}

	public MyRoute(List<Location> listLocations) {
		super();
		this.listLocations = listLocations;
	}

	public List<Location> getListLocations() {
		return listLocations;
	}

	public void setListLocations(List<Location> listLocations) {
		this.listLocations = listLocations;
	}
	
	
	
}
