package com.boostramp.skillzenza.locations;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface LocationRepository extends JpaRepository<LocusPoint, Integer>{
	

	@Query(value = "SELECT * FROM locusjulydata" , nativeQuery = true)
	public ArrayList<LocusPoint> findMyAll();
	
	@Query(value = "SELECT * FROM locusjulydata where user_id=:userId" , nativeQuery = true)
	public ArrayList<LocusPoint> findPointByUserId(@Param("userId")String userId);
	
	
}
