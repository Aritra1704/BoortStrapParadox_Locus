package com.boostramp.skillzenza.locations;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.boostramp.skillzenza.modal.locasmodals.Leg;
import com.boostramp.skillzenza.modal.locasmodals.LocusResponse;
import com.boostramp.skillzenza.modal.locasmodals.Route;
import com.boostramp.skillzenza.modal.locasmodals.Step;

@Service
public class LocationService {

	@Autowired
	private LocationRepository locationRepository;
	
	@Autowired
	private TempOSRMLocationRepository tempOSRMLocationRepository;
	
	public List<MyRoute> getAllRoutes(String reqParam) {
		
		LocusResponse locusResponse  = new LocusResponse();
		List<MyRoute> listMyRoutes = new ArrayList<MyRoute>();
		try {
//			System.out.println(locationRepository.findPointByUserId("User-13967"));
			
			String  url = "http://osrm-1644136849.us-east-1.elb.amazonaws.com/route/v1/driving/"+reqParam+"?overview=false&alternatives=true&steps=true&hints=;";	
			RestTemplate restTemplate = new RestTemplate();
			locusResponse = restTemplate.getForObject(url, LocusResponse.class);
			
			for(Route route : locusResponse.getRoutes()) {
				MyRoute myRoute = new MyRoute();
				List<Location> myRouteLocations = new ArrayList<Location>();
				if(route.getLegs()!=null) {
					
					Leg leg = route.getLegs().get(0);
					
					if(leg.getSteps()!=null && leg.getSteps().size()>0) {
						for(Step step : leg.getSteps()) {
							Location location = new Location();
							location.setLatitute(step.getManeuver().getLocation().get(1));
							location.setLongitude(step.getManeuver().getLocation().get(0));
							myRouteLocations.add(location);
						}
						
					myRoute.setListLocations(myRouteLocations);	
					}
					
					listMyRoutes.add(myRoute);	
					tempOSRMLocationRepository.deleteAll();
					tempOSRMLocationRepository.saveAll(myRoute.getListLocations());
				} 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listMyRoutes;
	}
}
