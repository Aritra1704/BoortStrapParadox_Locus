package com.boostramp.skillzenza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocasApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocasApiApplication.class, args);
	}

}
