package com.boostramp.skillzenza.modal.locasmodals;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "bearing_after",
    "type",
    "modifier",
    "bearing_before",
    "location"
})
public class Maneuver {

    @JsonProperty("bearing_after")
    private Integer bearingAfter;
    @JsonProperty("type")
    private String type;
    @JsonProperty("modifier")
    private String modifier;
    @JsonProperty("bearing_before")
    private Integer bearingBefore;
    @JsonProperty("location")
    private List<Double> location = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("bearing_after")
    public Integer getBearingAfter() {
        return bearingAfter;
    }

    @JsonProperty("bearing_after")
    public void setBearingAfter(Integer bearingAfter) {
        this.bearingAfter = bearingAfter;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("modifier")
    public String getModifier() {
        return modifier;
    }

    @JsonProperty("modifier")
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    @JsonProperty("bearing_before")
    public Integer getBearingBefore() {
        return bearingBefore;
    }

    @JsonProperty("bearing_before")
    public void setBearingBefore(Integer bearingBefore) {
        this.bearingBefore = bearingBefore;
    }

    @JsonProperty("location")
    public List<Double> getLocation() {
        return location;
    }

    @JsonProperty("location")
    public void setLocation(List<Double> location) {
        this.location = location;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
